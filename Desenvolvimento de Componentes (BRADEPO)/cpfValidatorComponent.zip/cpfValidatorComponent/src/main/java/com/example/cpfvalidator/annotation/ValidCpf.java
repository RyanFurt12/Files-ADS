package com.example.cpfvalidator.annotation;

import com.example.cpfvalidator.validator.CpfValidator;
import jakarta.validation.Constraint;
import jakarta.validation.Payload;
import java.lang.annotation.*;

@Target({ElementType.FIELD, ElementType.PARAMETER})
@Retention(RetentionPolicy.RUNTIME)
@Constraint(validatedBy = CpfValidator.class)
@Documented
public @interface ValidCpf {
    String message() default "CPF inválido";
    Class<?>[] groups() default {};
    Class<? extends Payload>[] payload() default {};
    
    boolean formatted() default true; // Aceita CPF formatado?
    boolean required() default true;   // Campo obrigatório?
}