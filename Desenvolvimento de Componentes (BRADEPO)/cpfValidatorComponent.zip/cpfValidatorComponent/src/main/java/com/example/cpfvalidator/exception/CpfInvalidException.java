package com.example.cpfvalidator.exception;

public class CpfInvalidException extends RuntimeException {
    public CpfInvalidException(String message) {
        super(message);
    }
    
    public CpfInvalidException(String message, Throwable cause) {
        super(message, cause);
    }
}