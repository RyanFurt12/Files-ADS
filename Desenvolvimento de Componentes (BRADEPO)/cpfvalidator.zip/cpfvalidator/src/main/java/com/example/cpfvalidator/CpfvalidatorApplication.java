package com.example.cpfvalidator;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.jdbc.autoconfigure.DataSourceAutoConfiguration;

@SpringBootApplication(exclude = {DataSourceAutoConfiguration.class})
public class CpfvalidatorApplication {

	public static void main(String[] args) {
		SpringApplication.run(CpfvalidatorApplication.class, args);
	}

}
