package com.example.cpfvalidator.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

@Service
public class CpfService {
    public Map<String, Object> verificarCpf(String cpf) {
        Map<String, Object> resposta = new HashMap<>();
        String cpfLimpo = this.limparCpf(cpf);

        if (cpfLimpo.length() != 11) {
            resposta.put("erro", "CPF deve ter 11 dígitos");
            resposta.put("valido", false);
            return resposta;
        }
        if (cpfLimpo.matches("(\\d)\\1{10}")) {
            resposta.put("erro", "CPF inválido");
            resposta.put("valido", false);
            return resposta;
        }

        int soma1 = 0;
        for (int i = 0; i < 9; i++) {
            soma1 += Character.getNumericValue(cpfLimpo.charAt(i)) * (10 - i);
        }
        int digito1 = (soma1 % 11) < 2 ? 0 : 11 - (soma1 % 11);
        int soma2 = 0;
        for (int i = 0; i < 10; i++) {
            soma2 += Character.getNumericValue(cpfLimpo.charAt(i)) * (11 - i);
        }
        int digito2 = (soma2 % 11) < 2 ? 0 : 11 - (soma2 % 11);
        int digitoInformado1 = Character.getNumericValue(cpfLimpo.charAt(9));
        int digitoInformado2 = Character.getNumericValue(cpfLimpo.charAt(10));
        if (digito1 != digitoInformado1 || digito2 != digitoInformado2) {
            resposta.put("erro", "Dígitos verificadores inválidos");
            resposta.put("valido", false);
            return resposta;
        }

        resposta.put("valido", true);
        resposta.put("cpfLimpo", cpfLimpo);
        resposta.put("cpfFormatado", this.formatarCpf(cpfLimpo));
        return resposta;
    }


    public String formatarCpf(String cpf) {
        cpf = this.limparCpf(cpf);
        return String.format("%s.%s.%s-%s",
                cpf.substring(0, 3),
                cpf.substring(3, 6),
                cpf.substring(6, 9),
                cpf.substring(9, 11));
    }

    public String limparCpf(String cpf) { return cpf.replaceAll("[^0-9]", ""); }
}