package com.example.cpfvalidator.service;

import java.util.HashMap;
import java.util.Map;

import org.springframework.stereotype.Service;

import com.example.cpfvalidator.repository.ValidacaoRepository;

@Service
public class ValidacaoService {
    ValidacaoRepository db = new ValidacaoRepository();

    public Map<String, Object> validarCpf(String cpf, String usuarioId) {
        Map<String, Object> resposta = new HashMap<>();
        resposta = new CpfService().verificarCpf(cpf);

        if(!Boolean.TRUE.equals(resposta.get("valido"))) return resposta;

        String cpfLimpo = (String) resposta.get("cpfLimpo");
        String cpfFormatado = (String) resposta.get("cpfFormatado");

        db.insertValidacao((String) resposta.get("cpfLimpo"), usuarioId);
        new EmailService().enviarEmailConfirmacao(usuarioId, cpfFormatado);
        new LoggerService().enviarLogConfirmacao(usuarioId, cpfLimpo);

        resposta.put("cpf", cpfFormatado);
        resposta.put("mensagem", "CPF válido e registrado");
        resposta.put("valido", true);
        return resposta;
    }
}