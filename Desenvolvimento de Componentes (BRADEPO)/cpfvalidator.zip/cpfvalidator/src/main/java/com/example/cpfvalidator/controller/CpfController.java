package com.example.cpfvalidator.controller;

import org.springframework.web.bind.annotation.*;

import com.example.cpfvalidator.service.CpfService;
import com.example.cpfvalidator.service.ValidacaoService;

import org.springframework.beans.factory.annotation.Autowired;
import java.util.*;

@RestController
public class CpfController {
    @Autowired
    private CpfService cpfService;
    @Autowired
    private ValidacaoService validacaoService;

    @PostMapping("/cpf/validar")
    public Map<String, Object> validarCpf(@RequestBody Map<String, String> request) {
        Map<String, Object> resposta = new HashMap<>();
        try {
            String cpf = request.get("cpf");
            String usuarioId = request.get("usuarioId");
            
            resposta = validacaoService.validarCpf(cpf, usuarioId);            
        } catch (Exception e) {
            resposta.put("erro", e.getMessage());
            resposta.put("valido", false);
        }
        return resposta;
    }

    @GetMapping("/cpf/verificar/{cpf}")
    public Map<String, Object> verificarCpf(@PathVariable String cpf) {
        return cpfService.verificarCpf(cpf);
    }
}