package com.example.cpfvalidator.service;

import org.springframework.stereotype.Service;


@Service
public class EmailService {
    public void enviarEmailConfirmacao(String usuarioId, String cpf) {
        System.out.println("Enviando email para usuário " + usuarioId + " - CPF: " + cpf);
    }
}