package com.example.cpfvalidator.service;

import org.springframework.stereotype.Service;


@Service
public class LoggerService {
    public void enviarLogConfirmacao(String usuarioId, String cpfLimpo) {
        System.out.println("CPF validado: " + cpfLimpo + " para usuário: " + usuarioId);
    }
}