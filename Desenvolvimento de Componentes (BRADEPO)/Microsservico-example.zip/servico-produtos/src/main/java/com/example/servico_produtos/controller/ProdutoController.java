package com.example.servico_produtos.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.example.servico_produtos.model.Produto;
import com.example.servico_produtos.repository.ProdutoRepository;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/produtos")
public class ProdutoController {
    
    @Autowired
    private ProdutoRepository produtoRepository;
    
    @GetMapping
    public List<Produto> listarTodos() {
        return produtoRepository.findAll();
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<Produto> buscarPorId(@PathVariable Long id) {
        Optional<Produto> produto = produtoRepository.findById(id);
        return produto.map(ResponseEntity::ok)
                     .orElse(ResponseEntity.notFound().build());
    }
    
    @PostMapping
    public ResponseEntity<Produto> criar(@RequestBody Produto produto) {
        Produto salvo = produtoRepository.save(produto);
        return ResponseEntity.status(HttpStatus.CREATED).body(salvo);
    }
    
    @PutMapping("/{id}/estoque")
    public ResponseEntity<?> atualizarEstoque(@PathVariable Long id, 
                                              @RequestParam Integer quantidade) {
        Optional<Produto> optional = produtoRepository.findById(id);
        if (optional.isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        
        Produto produto = optional.get();
        int novoEstoque = produto.getEstoque() - quantidade;
        
        if (novoEstoque < 0) {
            return ResponseEntity.badRequest()
                .body("Estoque insuficiente. Disponível: " + produto.getEstoque());
        }
        
        produto.setEstoque(novoEstoque);
        produtoRepository.save(produto);
        return ResponseEntity.ok(produto);
    }
}
