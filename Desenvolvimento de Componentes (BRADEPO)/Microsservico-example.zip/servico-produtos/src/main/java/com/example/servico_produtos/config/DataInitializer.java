package com.example.servico_produtos.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import com.example.servico_produtos.model.Produto;
import com.example.servico_produtos.repository.ProdutoRepository;

@Component
public class DataInitializer implements CommandLineRunner {
    
    @Autowired
    private ProdutoRepository produtoRepository;
    
    @Override
    public void run(String... args) throws Exception {
        produtoRepository.save(new Produto("Notebook Dell", 3500.00, 10));
        produtoRepository.save(new Produto("Mouse Logitech", 150.00, 25));
        produtoRepository.save(new Produto("Teclado Mecânico", 300.00, 15));
        produtoRepository.save(new Produto("Monitor LG", 1200.00, 8));
        
        System.out.println("Produtos inicializados com sucesso!");
    }
}