package com.example.cpfvalidator.service;

import org.springframework.stereotype.Service;

import com.example.cpfvalidator.DTO.CpfResponse;

@Service
public class CpfService {
    public CpfResponse verificarCpf(String cpf) {
        String cpfLimpo = this.limparCpf(cpf);

        if (cpfLimpo.length() != 11 || cpfLimpo.matches("(\\d)\\1{10}")) {
            this.throwCpfInvalido();
        }

        int soma1 = 0;
        for (int i = 0; i < 9; i++) {
            soma1 += Character.getNumericValue(cpfLimpo.charAt(i)) * (10 - i);
        }
        int digito1 = (soma1 % 11) < 2 ? 0 : 11 - (soma1 % 11);
        int soma2 = 0;
        for (int i = 0; i < 10; i++) {
            soma2 += Character.getNumericValue(cpfLimpo.charAt(i)) * (11 - i);
        }
        int digito2 = (soma2 % 11) < 2 ? 0 : 11 - (soma2 % 11);
        int digitoInformado1 = Character.getNumericValue(cpfLimpo.charAt(9));
        int digitoInformado2 = Character.getNumericValue(cpfLimpo.charAt(10));
        
        if (digito1 != digitoInformado1 || digito2 != digitoInformado2) {
            this.throwCpfInvalido();
        }

        return CpfResponse.sucesso(cpfLimpo, formatarCpf(cpfLimpo));
    }

    public String formatarCpf(String cpf) {
        cpf = this.limparCpf(cpf);
        return String.format("%s.%s.%s-%s",
                cpf.substring(0, 3), cpf.substring(3, 6),
                cpf.substring(6, 9), cpf.substring(9, 11));
    }

    public String limparCpf(String cpf) { return cpf.replaceAll("[^0-9]", ""); }

    private void throwCpfInvalido(){ 
        throw new IllegalArgumentException("CPF inválido ou com formato incorreto");
    }
}