package com.example.cpfvalidator.service;

import org.springframework.stereotype.Service;

import com.example.cpfvalidator.DTO.CpfResponse;
import com.example.cpfvalidator.repository.ValidacaoRepository;

@Service
public class ValidacaoService {
    ValidacaoRepository db = new ValidacaoRepository();

    public CpfResponse salvarValidacao(CpfResponse cr, String userId){
        db.insertValidacao((String) cr.getCpfLimpo(), userId);
        new EmailService().enviarEmailConfirmacao(userId, cr.getCpfFormatado());
        new LoggerService().enviarLogConfirmacao(userId, cr.getCpfLimpo());

        return cr;
    }
}