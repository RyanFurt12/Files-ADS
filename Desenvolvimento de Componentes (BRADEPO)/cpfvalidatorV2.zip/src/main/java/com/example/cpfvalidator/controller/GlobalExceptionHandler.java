package com.example.cpfvalidator.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.example.cpfvalidator.DTO.CpfResponse;
import com.example.cpfvalidator.exception.CpfInvalidException;

@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<CpfResponse> handleIllegalArgument(IllegalArgumentException ex) {
        CpfResponse resposta = new CpfResponse(false, null, null, ex.getMessage());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(resposta);
    }

    @ExceptionHandler(CpfInvalidException.class)
    public ResponseEntity<CpfResponse> handleCpfInvalid(CpfInvalidException ex) {
        CpfResponse resposta = new CpfResponse(false, null, null, ex.getMessage());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(resposta);
    }
}
