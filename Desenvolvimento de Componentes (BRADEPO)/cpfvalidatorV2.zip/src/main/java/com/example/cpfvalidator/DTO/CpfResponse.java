package com.example.cpfvalidator.DTO;

public record CpfResponse(
    boolean valido,
    String cpfLimpo,
    String cpfFormatado,
    String mensagem
) {
    public static CpfResponse sucesso(String limpo, String formatado) {
        return new CpfResponse(true, limpo, formatado, null);
    }

    public boolean getValido(){ return this.valido; }
    public String getCpfLimpo(){ return this.cpfLimpo; }
    public String getCpfFormatado(){ return this.cpfFormatado; }
}