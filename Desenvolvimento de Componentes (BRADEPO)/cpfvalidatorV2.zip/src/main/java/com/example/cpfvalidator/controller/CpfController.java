package com.example.cpfvalidator.controller;

import org.springframework.web.bind.annotation.*;

import com.example.cpfvalidator.DTO.CpfResponse;
import com.example.cpfvalidator.service.CpfService;
import com.example.cpfvalidator.service.ValidacaoService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import java.util.*;

@RestController
public class CpfController {
    @Autowired
    private CpfService cpfService;
    @Autowired
    private ValidacaoService validacaoService;

    @PostMapping("/cpf/validar")
    public ResponseEntity<CpfResponse> validarCpf(@RequestBody Map<String, String> request) {
        String cpf = request.get("cpf");
        String usuarioId = request.get("usuarioId");

        CpfResponse cpfResponse = cpfService.verificarCpf(cpf);
        return ResponseEntity.ok(validacaoService.salvarValidacao(cpfResponse, usuarioId));
    }

    @GetMapping("/cpf/verificar/{cpf}")
    public ResponseEntity<CpfResponse> verificarCpf(@PathVariable String cpf) {
        return ResponseEntity.ok(cpfService.verificarCpf(cpf));
    }
}