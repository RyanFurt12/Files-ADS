package com.example.cpfvalidator.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.cpfvalidator.DTO.CpfResponse;

@Service
public class CpfService {

    @Autowired
    private CpfValidationService cpfValidationService;

    public CpfResponse verificarCpf(String cpf) {
        if (!cpfValidationService.isValid(cpf)) {
            throw new IllegalArgumentException("CPF inválido ou com formato incorreto");
        }

        String cpfLimpo = cpf.replaceAll("[^0-9]", "");
        String cpfFormatado = cpfValidationService.formatar(cpfLimpo);

        return CpfResponse.sucesso(cpfLimpo, cpfFormatado);
    }
}