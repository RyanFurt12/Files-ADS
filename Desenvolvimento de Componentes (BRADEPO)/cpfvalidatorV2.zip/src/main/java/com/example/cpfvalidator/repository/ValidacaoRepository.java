package com.example.cpfvalidator.repository;

import java.util.Date;

//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.jdbc.core.JdbcTemplate;

public class ValidacaoRepository {
    //@Autowired
    //private JdbcTemplate jdbcTemplate;

    public void insertValidacao(String cpf, String usuarioId){
        System.out.println("CPF validado: " + cpf + " para usuário: " + usuarioId + " na data: " + new Date());

        //jdbcTemplate.update("INSERT INTO validacoes (cpf, usuario_id, data_validacao) VALUES(?, ?, ?)",
        //        cpf, usuarioId, new Date());
    }
}
